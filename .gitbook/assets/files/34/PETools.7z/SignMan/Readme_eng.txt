======================================================================
PE Tools Signature Manager v1.0 by NEOx
======================================================================

I.   What is it
II.  How to use it.
III. History
IV.  Contacts.

I. What is it.
--------------------
This  utility  is  designed for creating the signatures for PE Sniffer
which is the part of PE Tools.


II. How to use it.
--------------------
At  the  beginning you have to open two DIFFERENT file that need to be
packed  with THE SAME packer (but different packing options). Then you
press  "Compare"  and  the  tool  will  show  you  the  bytes that are
identical.  You  can  select  the  neccesary  bytes  (select the bytes
whatever you like and as much as you like) all together or selectively
(hold Shift-button). Then you press "<" and "Generate". Voila! Here is
your  signature.  Add  it  to Signs.txt. Enjoy it. And don't forget to
send it to me!!!



III. History.
--------------------
31.08.03 - v1.0
   - First version. No bugs, beleive it or not :)



IV. Contacts.
--------------------
Send me emails to NEOx@Pisem.net

[Thanks: Volodya/WASM.RU]



=== by NEOx [E-Mail: NEOx@Pisem.net] =============== 31.08.03 ============
=== [c] Underground Information Center [ http://www.uinc.ru ] ============