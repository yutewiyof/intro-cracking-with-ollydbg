CrackMePls by: Bootloader (Visual Basic)

Very Easy Crackme.

You need:

1. Patch it (to remove the Nag, and accept any password)
2. Find what the real password.
3. That's All, and Enjoy!

Http://PinoyRakista.Tk